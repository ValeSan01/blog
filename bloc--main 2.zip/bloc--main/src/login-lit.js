import { LoginLit } from './LoginLit.js';

customElements.define('login-lit', LoginLit);
